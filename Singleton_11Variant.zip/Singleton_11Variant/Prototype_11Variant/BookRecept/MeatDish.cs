﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prototype_11Variant.BookRecept
{
    public class MeatDish : Recipe
    {
        public string Medium { get; set; }
        public string MediumRare { get; set; }
        public string Rare { get; set; }

        public MeatDish(string medium, string mediumRare, string rare)
        {
            Medium = medium;
            MediumRare = mediumRare;
            Rare = rare;
        }
        public override Recipe Clone()
        {
            return MemberwiseClone() as MeatDish;
        }
        public override string ToString()
        {
            return $" Прожарка {Medium} или {MediumRare} или {Rare}";
        }
    }
}
