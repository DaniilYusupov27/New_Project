﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prototype_11Variant.BookRecept
{
    internal class Dessert : Recipe
    {
        public int Sugar { get; set; }
        public Dessert(int sugar)
        {
            Sugar = sugar;
        }
        public override Recipe Clone()
        {
            return MemberwiseClone() as Dessert;
        }
        public override string ToString()
        {
            return $"Десерт имеет {Sugar} грамм сахара";
        }
    }
}
