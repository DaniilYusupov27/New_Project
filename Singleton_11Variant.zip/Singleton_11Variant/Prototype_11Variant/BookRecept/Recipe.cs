﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prototype_11Variant.BookRecept
{
    public abstract class Recipe
    {
        public abstract Recipe Clone();
        public override abstract string ToString();
    }
}
