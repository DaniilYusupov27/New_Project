﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prototype_11Variant.BookRecept
{
    internal class VegaterianDish : Recipe
    {
        public int Gramm { get; set; }

        public VegaterianDish(int gramm) 
        {
            Gramm = gramm;
        }

        public override Recipe Clone()
        {
            return MemberwiseClone() as VegaterianDish;
        }
        public override string ToString()
        {
            return $"салат, {Gramm}";
        }
    }
}
