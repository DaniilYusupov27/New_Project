﻿using Prototype_11Variant.BookRecept;

public class Program
{
    static void Main(string[] args)
    {
        Recipe originalMeatDish = new MeatDish("rare", "rare", "rare");
        Recipe clonedMeatDish = originalMeatDish.Clone();

        Console.WriteLine($"Мясо прожарки: {originalMeatDish}");
        Console.WriteLine($"Клонированое мясо прожарки: {clonedMeatDish}");

        Recipe originalVegaterianDish = new VegaterianDish(354);
        Recipe clonedVegaterianDish = originalVegaterianDish.Clone();

        Console.WriteLine($"Салат имеет : {originalVegaterianDish} ценности");
        Console.WriteLine($"Клонированое Салат имеет: {clonedVegaterianDish} ценности");


        Recipe originalDessert = new Dessert(2334);
        Recipe clonedDessert = originalDessert.Clone();

        Console.WriteLine($"Десерт имеет: {originalDessert} грамм сахара");
        Console.WriteLine($"Клонированое Десерт имеет: {clonedDessert}");
    }
}