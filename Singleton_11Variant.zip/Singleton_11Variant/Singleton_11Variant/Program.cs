﻿using Singleton_11Variant.PerfomansMonitor;

public class Program
{
    static void Main(string[] args)
    {
        Perfomans perfomans = new Perfomans();
        perfomans.Launch("Radeon5", "27%");
        Console.WriteLine($"CPU Name {perfomans.CPU.Name} CPU: {perfomans.CPU.CPU}");

        perfomans.Launch("Radeon6", "12%");
        Console.WriteLine($"CPU Name {perfomans.CPU.Name} CPU: {perfomans.CPU.CPU}");
        Console.ReadLine();

    }
}