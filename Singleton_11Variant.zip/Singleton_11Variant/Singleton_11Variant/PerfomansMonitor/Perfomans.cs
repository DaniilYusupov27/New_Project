﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Singleton_11Variant.PerfomansMonitor
{
    internal class Perfomans
    {
        public PerfomansMonitors CPU { get; set; }
        public void Launch(string cName, string cCPU)
        {
            CPU = PerfomansMonitors.getPerfomansMonitor(cName, cCPU);
        }
    }
}
