﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Singleton_11Variant.PerfomansMonitor
{
    internal class PerfomansMonitors
    {
        private static PerfomansMonitors _perfomansMonitor;
        public string Name { get; private set; }
        public string CPU {  get; private set; }
        protected PerfomansMonitors(string name, string cpu) 
        {
            Name = name;
            CPU = cpu;
        }

        public static PerfomansMonitors getPerfomansMonitor(string name, string cpu)
        {
            if (_perfomansMonitor == null)
            {
                _perfomansMonitor = new PerfomansMonitors(name, cpu);
            }
            return _perfomansMonitor;
        }
    }
    
}
