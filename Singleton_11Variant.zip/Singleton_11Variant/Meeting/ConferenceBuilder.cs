﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Meeting
{
    internal class ConferenceBuilder : BuildMeet
    {
        private readonly Meet _meet = new Meet();
        public void SetPeople()
        {
            _meet.People = 16;
        }
        public void SetAdress()
        {
            _meet.Adress = "Центральная 19";
        }
        public void SetName()
        {
            _meet.Name = "Разговор о наркозависимости";
        }
        public Meet GetMeet()
        {
            return _meet;
        }
    }
}
