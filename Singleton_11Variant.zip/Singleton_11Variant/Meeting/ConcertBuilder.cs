﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Meeting
{
    internal class ConcertBuilder : BuildMeet
    {
        private readonly Meet _meet = new Meet();
        public void SetPeople()
        {
            _meet.People = 6000;
        }
        public void SetAdress()
        {
            _meet.Adress = "Олимпийский ледовый дворец";
        }
        public void SetName()
        {
            _meet.Name = "Концерт Шамана";
        }
        public Meet GetMeet()
        {
            return _meet;
        }
    }
}
