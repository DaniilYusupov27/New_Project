﻿using Meeting;

class Program
{
    static void Main(string[] args)
    {
        var ConcertDirector = new DirectorMeeting(new ConcertBuilder());
        ConcertDirector.ConsructMeet();
        var Conc = ConcertDirector.GetMeet();
        Console.WriteLine("Концерт: ");
        Console.WriteLine($"Адрес мероприятия: {Conc.Adress}, кол-во человек: {Conc.People}, название мероприятия: {Conc.Name}\n");

        var WeddDirector = new DirectorMeeting(new WeddingBuilder());
        WeddDirector.ConsructMeet();
        var wedd = WeddDirector.GetMeet();
        Console.WriteLine("Свадьба: ");
        Console.WriteLine($"Адрес мероприятия: {wedd.Adress}, кол-во человек: {wedd.People}, название мероприятия: {wedd.Name}\n");

        var ConfDirector = new DirectorMeeting(new ConferenceBuilder());
        ConfDirector.ConsructMeet();
        var conf = ConfDirector.GetMeet();
        Console.WriteLine("Конфиренция: ");
        Console.WriteLine($"Адрес мероприятия: {conf.Adress}, кол-во человек: {conf.People}, название мероприятия: {conf.Name}\n");
    }
}