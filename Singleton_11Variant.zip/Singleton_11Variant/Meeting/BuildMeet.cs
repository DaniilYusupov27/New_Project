﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Meeting
{
    internal interface BuildMeet
    {
        void SetPeople();
        void SetAdress();
        void SetName();
        Meet GetMeet();
    }
}
