﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Meeting
{
    internal class DirectorMeeting
    {
        private readonly BuildMeet _buildMeet;
        public DirectorMeeting(BuildMeet buildMeet)
        {
            _buildMeet = buildMeet;
        }
        public void ConsructMeet()
        {
            _buildMeet.SetPeople();
            _buildMeet.SetAdress();
            _buildMeet.SetName();
        }
        public Meet GetMeet()
        {
            return _buildMeet.GetMeet();
        }
    }
}
