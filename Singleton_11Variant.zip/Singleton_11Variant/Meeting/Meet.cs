﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Meeting
{
    internal class Meet
    {
        public int People { get; set; }
        public string Adress { get; set; }
        public string Name { get; set; }
    }
}
