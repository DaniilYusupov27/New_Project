﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exemple.Class
{
    internal class Computer
    {
        // Содержит экземпляр операционной системы
        public OperationSystem OS { get; set; }
        // Метод "запуска" экземпляра операционной системы на компьютере
        public void Launch(string osName, string osVersion)
        {
            OS = OperationSystem.getOperationSystem(osName, osVersion);
        }
    }
}
