﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exemple.Class
{
    internal class OperationSystem
    {
        // Содержит в себе ссылку на конкретный экземпляр операционной системы
        private static OperationSystem _operationSystem;
        // Содержит наименование операционной системы
        public string Name { get; private set; }
        // Содержит версию операционной системы
        public string Version { get; private set; }
        // Операционная система создается на основе наименования и версии
        protected OperationSystem(string name, string version)
        {
            Name = name;
            Version = version;
        }
        public static OperationSystem getOperationSystem(string name, string version)
        {
            // Если операционная система отсутствует (объект пустой)
            if (_operationSystem == null)
            {
                // Создать экземпляр операционной системы
                _operationSystem = new OperationSystem(name, version);
            }
            // Возврат экземпляра операционной системы
            return _operationSystem;
        }
    }
}
