﻿using Exemple.Class;

public class Program
{
    static void Main(string[] args)
    {
        // "Создаем" компьютер
        Computer computer = new Computer();
        // "Запускаем" на компьютере операционную систему Windows 10
        computer.Launch("Windows", "10");
        Console.WriteLine($"Запущена {computer.OS.Name} {computer.OS.Version}");
        // Попытаемся "запустить" на компьютере операционную систему Windows 11 
        // Не получится это сделать, т.к. другая операционная система уже "запущена"
        computer.Launch("Windows", "11");
        // Получим "старую" версию операционной системы (Windows 10)
        Console.WriteLine($"Запущена {computer.OS.Name} {computer.OS.Version}");
        Console.ReadLine();
    }
}
