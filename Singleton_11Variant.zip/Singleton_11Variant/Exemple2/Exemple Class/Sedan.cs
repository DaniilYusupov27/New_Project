﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exemple2.Exemple_Class
{
    internal class Sedan : ICarBuilder
    {
        private readonly Car _car = new Car();
        public void SetEngine()
        {
            _car.Engine = "V6";
        }
        public void SetWheels()
        {
            _car.Wheels = 4;
        }
        public void SetBody()
        {
            _car.Body = "Sedan";
        }
        public Car GetCar()
        {
            return _car;
        }

    }
}
