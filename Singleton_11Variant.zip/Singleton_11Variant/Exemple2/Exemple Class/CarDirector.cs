﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exemple2.Exemple_Class
{
    internal class CarDirector
    {
        private readonly ICarBuilder _builder;
        public CarDirector(ICarBuilder builder)
        {
            _builder = builder;
        }
        // Метод сборки автомобиля
        public void ConstructCar()
        {
            _builder.SetEngine();
            _builder.SetWheels();
            _builder.SetBody();
        }
        public Car GetCar()
        {
            return _builder.GetCar();
        }
    }
}
