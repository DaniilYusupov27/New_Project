﻿using Exemple2.Exemple_Class;

class Program
{
    static void Main(string[] args)
    {
        // Создаем седан
        var sedanDirector = new CarDirector(new Sedan());
        sedanDirector.ConstructCar();
        var sedan = sedanDirector.GetCar();
        Console.WriteLine("Седан:");
        Console.WriteLine($"Двигатель: {sedan.Engine}, кол-во колес: {sedan.Wheels}, тип кузова: { sedan.Body}\n");
    // Создаем спортивный автомобиль
        var sportCarDirector = new CarDirector(new Sport());
        sportCarDirector.ConstructCar();
        var sportCar = sportCarDirector.GetCar();
        Console.WriteLine("Спортивный автомобиль:");
        Console.WriteLine($"Двигатель: {sportCar.Engine}, кол-во колес: { sportCar.Wheels}, тип кузова: { sportCar.Body}\n");
    // Создаем грузовик
        var truckDirector = new CarDirector(new Truck());
        truckDirector.ConstructCar();
        var truck = truckDirector.GetCar();
        Console.WriteLine("Грузовик:");
        Console.WriteLine($"Двигатель: {truck.Engine}, кол-во колес: {truck.Wheels}, тип кузова: { truck.Body}\n");
   

        Console.ReadKey();
        Console.ReadKey();
    }
}